#!flask/bin/python
from flaskr.db_create import createdb
from flaskr.db_migrate import dbMigrate
#createdb()
dbMigrate()