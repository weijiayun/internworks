#!flask/bin/python
from multiprocessing import Process
from flaskr import app


def runWeb():
    #app.debug=True
   # ErrorMail()
    #ErrorLog()
    app.run()

p1=Process(target=runWeb,name='process_runWeb')
p1.start()
p1.join()




