#!flask/bin/python
#all the import
from flask import redirect,request,Blueprint,\
    session,url_for,g,abort,render_template,flash

#all the strategies
viewpages=Blueprint('viewpages',__name__,
                      template_folder='templates/viewpages')


@viewpages.route('/')
def show_entries():
    cur=g.entry_db.execute('select title,text from entries order by id desc')
    entries=[dict(title=row[0],text=row[1]) for row in cur.fetchall()]
    return render_template('show_entries.html',entries=entries)

@viewpages.route('/add',methods=['POST'])
def add_entry():
    if not session.get('logged_in'):
        abort(401)
    g.entry_db.execute('insert into entries (title,text) values (?,?)',
                 [request.form['title'],request.form['text']])
    if len(request.form['title'])==0 or len(request.form['text'])==0:
        flash('Both Title and text cannot be empty')
        return redirect(url_for('.show_entries'))
    g.entry_db.commit()
    flash('New entry was successfully posted')
    return redirect(url_for('.show_entries'))



