#!flask/bin/python
from flask import redirect,request,\
    session,url_for,g,abort,render_template,flash
from flaskr import app


@app.route('/login',methods=['GET','POST'])
def login():
    error = None
    if request.method == 'POST':
        cur = g.user_db.execute('select username,password from userinfo order by id desc')
        usersInfo = [dict(username=row[0], password=row[1]) for row in cur.fetchall()]
        userlist=[]
        for foo in usersInfo:
            userlist.append(foo['username'])
        if request.form['username'] not in userlist:
            error='The Account Is Not Signed'
        else:
            userindex = userlist.index(request.form['username'])
            if request.form['password']!=usersInfo[userindex]['password']:
                error='The Password Cannot Match The Account'
            else:
                session['logged_in']=True
                flash('You were logged in successfully')
                return redirect(url_for('viewpages.show_entries'))

    return render_template('login.html',error=error)

@app.route('/logout')
def logout():
    session.pop('logged_in',None)
    flash('You were logged out')
    return redirect(url_for('viewpages.show_entries'))

@app.route('/signup',methods=['GET','POST'])
def signup():
    error = None
    if request.method == 'POST':
        print request.method
        if session.get('logged_in'):
            abort(401)
        g.user_db.execute('insert into userinfo (username,password) values (?,?)',
                          [request.form['username'], request.form['password1']])
        if len(request.form['username'])==0 or len(request.form['password1'])==0 or len(request.form['password2'])==0:
            error='Those information shall not be empty'
        elif request.form['password1']!=request.form['password2']:
            error='password1 cannot match the password2'
        else:
            g.user_db.commit()
            flash('New account has been successfully signed up')
            return redirect(url_for('login'))
    return render_template('signup.html',error=error)

