from flask import Flask
app=Flask(__name__, template_folder='templates/main')
app.config.from_object('config')

######sql initialize#############

from flask.ext.sqlalchemy import SQLAlchemy
db=SQLAlchemy(app)

#####blueprint registe###########
from flaskr.entries import viewpages
import entries,loginset,models,config

app.register_blueprint(viewpages)


