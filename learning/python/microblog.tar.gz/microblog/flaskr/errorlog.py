#!flask/bin/python
from flaskr import app
def ErrorMail():
    ADMINS = ['294311951@qq.com']
    MAIL_SERVER = 'localhost'
    host = ('localhost', 25)
    if not app.debug:
        import logging
        from logging.handlers import SMTPHandler
        mail_handler = SMTPHandler(host,
                                   'no-reply@' + MAIL_SERVER,
                                   ADMINS, 'Flaskr Failed')
        from logging import Formatter
        mail_handler.setFormatter(Formatter('''

Messagetype:        %(levelname)s
Location:           %(pathname)s:%(lineno)d
Module:             %(module)s
Function:           %(funcName)s
Time:               %(asctime)s

Message:

%(message)s
'''))
        mail_handler.setLevel(logging.ERROR)
        app.logger.addHandler(mail_handler)

def ErrorLog():
    if not app.debug:
        import logging
        from logging.handlers import RotatingFileHandler
        file_handler = RotatingFileHandler('tmp/Jiayunblog.log', 'a', 1 * 1024 * 1024, 10)
        file_handler.setFormatter(
            logging.Formatter('%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'))
        app.logger.setLevel(logging.INFO)
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)
        app.logger.info('microblog startup')